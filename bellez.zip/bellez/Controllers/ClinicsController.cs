﻿using Microsoft.AspNetCore.Mvc;

namespace bellez.Controllers
{
    public class ClinicsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
