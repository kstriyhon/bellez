﻿using bellez.Models;
using Microsoft.AspNetCore.Mvc;

namespace bellez.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Submit(contacto model)
        {
            if (ModelState.IsValid)
            {
                // TODO: Send email or save message to database
                ViewBag.Message = "Su mensaje ha sido enviado.";
                return View("Index");
            }
            return View("Index", model);
        }
    }
}
