﻿using bellez.Models;
using bellez.Servicios;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using bellez.Interfaces;
using bellez.ViewModels;
using CloudinaryDotNet.Actions;
using Dapper;
using Microsoft.Data.SqlClient;

namespace bellez.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IRepositorioMedicos repositorioMedicos;

        public HomeController(IRepositorioMedicos repositorioMedicos)
        {
            this.repositorioMedicos = repositorioMedicos;             
        }
        

        public async Task<IActionResult> Index()
        {
            var medicos = await repositorioMedicos.getmedicos();
            ViewBag.Medicos = medicos;
            var clinicas = await repositorioMedicos.GetClinicas();
            ViewBag.clinicas = clinicas;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

       

        public IActionResult mision()
        {
            return View();
        }

        public IActionResult vision()
        {
            return View();
        }

        public IActionResult acercade()
        {
            return View();
        }
    }
}
