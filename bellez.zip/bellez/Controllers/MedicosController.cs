﻿using bellez.Interfaces;
using bellez.Models;
using bellez.Servicios;
using bellez.ViewModels;
using CloudinaryDotNet.Actions;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace bellez.Controllers
{
    public class MedicosController : Controller
    {
        
        private readonly IRepositorioMedicos repositorioMedicos;
        public MedicosController(IRepositorioMedicos repositorioMedicos)
        {
           this.repositorioMedicos = repositorioMedicos;            
        }
        public object Model { get; private set; }
        public object Modelstate { get; private set; }
        
       

        public IPhotoService PhotoService { get; }

        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> detalle(int id)
        {
            var medico = await repositorioMedicos.getmedico(id);
            if (medico == null)
            {
                // Handle the null case appropriately, e.g., return a NotFound result
                return NotFound();
            }

            // Proceed with the rest of the logic if medico is not null
            ViewBag.medicos = medico;
            return View();
            
        }
        
    }
}
