﻿using bellez.Models;
using bellez.Servicios;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace bellez.Controllers
{
    public class MedicosController : Controller
    {
        public MedicosController(IRepositorioMedicos repositorioMedicos)
        {
           RepositorioMedicos = repositorioMedicos;
        }
        public object Model { get; private set; }
        public object Modelstate { get; private set; }
        public IRepositorioMedicos RepositorioMedicos { get; }

        public IActionResult Crear()
        {
           
            
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Crear(Medicos medicos)
        {
            if (!ModelState.IsValid)
            {
                return View(medicos);
            }

            await  RepositorioMedicos.CrearMedico(medicos);
            return View();
        }
    }
}
