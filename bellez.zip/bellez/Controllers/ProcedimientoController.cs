﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using AirtableApiClient;

namespace bellez.Controllers
{
    public class ProcedimientoController : Controller
    {
        readonly string baseId = "appQNu1XrpLA7eWne";
        

        //public token = "patPcXkYN4AF5qhUb.bd87e01493fa14d68cdd1ac89e44076c8b4512556dcd6fb9eea0cfd0787f31a9";
        public IActionResult Index()
        {
            var MY_TOKEN = "patPcXkYN4AF5qhUb.bd87e01493fa14d68cdd1ac89e44076c8b4512556dcd6fb9eea0cfd0787f31a9";
            return View();
        }
       
    }

}
