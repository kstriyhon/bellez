﻿

using bellez.Interfaces;
using bellez.Models;
using bellez.Servicios;
using bellez.ViewModels;
using CloudinaryDotNet.Actions;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace bellez.Controllers
{
    public class ClinicasController : Controller
    { 

    private readonly IRepositorioMedicos repositorioMedicos;
    public ClinicasController(IRepositorioMedicos repositorioMedicos)
    {
        this.repositorioMedicos = repositorioMedicos;
    }
    public object Model { get; private set; }
    public object Modelstate { get; private set; }
        
    
        public IActionResult Index()
        {
            return View();
           
        }

        public async Task<IActionResult> detalle(int id)
        {
            var clinica = await repositorioMedicos.getclinica(id);
            if (clinica == null)
            {
                // Handle the null case appropriately, e.g., return a NotFound result
                return NotFound();
            }

            // Proceed with the rest of the logic if medico is not null
            ViewBag.clinicas = clinica;
            return View();

        }
    }
}
