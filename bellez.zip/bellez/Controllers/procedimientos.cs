﻿using Microsoft.AspNetCore.Mvc;

namespace bellez.Controllers
{
    public class procedimientos : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
