﻿using CloudinaryDotNet.Actions;

namespace bellez.Interfaces
{
    public interface IPhotoService
    {
        Task <ImageUploadResult>AddPhotoAsync(IFormFile file);
        Task<DeletionResult> DeletePhotoAsync(string  publicId);
    }
}
