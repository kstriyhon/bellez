﻿using System.ComponentModel.DataAnnotations;

namespace bellez.Models
{
    public class Clinicas
    {
        [Key]
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Ciudad { get; set; }
        public string  Zona { get; set; }

        public string Imagen { get; set; }
        public string  Url { get; set; }

    }
}
