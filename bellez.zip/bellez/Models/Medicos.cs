﻿using System.ComponentModel.DataAnnotations;

namespace bellez.Models
{
    public class Medicos
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="El campo Nombre es requerido")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El campo Especialización es requerido")]
        public string Especializacion { get; set; }

        [Required(ErrorMessage = "El campo Experiencia es requerido")]
        public string Experiencia { get; set; }

        [Required(ErrorMessage = "El campo Años de Experiencia es requerido")]
        public int Años_experiencia { get; set; }
        
        
        public string  Foto { get; set; }
    }
}
