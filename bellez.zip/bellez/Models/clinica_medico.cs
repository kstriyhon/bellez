﻿using System.Diagnostics;

namespace bellez.Models
{
    public class clinica_medico
    {
        public IEnumerable<Medicos> medicos { get; set; }
        public IEnumerable<Clinicas> clinicas { get; set; }
    }
}
