﻿using System.ComponentModel.DataAnnotations;

namespace bellez.Models
{
    public class contacto
    {

        [Required]
        [Display(Name = "Your Name")]
        public string Nombre { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Your Email")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Subject")]
        public string Asunto { get; set; }

        [Required]
        [Display(Name = "Message")]
        public string Mensaje { get; set; }
    }
}
