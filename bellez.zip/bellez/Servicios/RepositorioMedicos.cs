﻿using bellez.Models;
using Dapper;
using Microsoft.Data.SqlClient;

namespace bellez.Servicios
{

    public interface IRepositorioMedicos
    {
        Task CrearMedico(Medicos medico);
    }
    public class RepositorioMedicos:IRepositorioMedicos
    {
        private readonly string connectionString;
        public RepositorioMedicos(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("defaultConnections");            
        }

        public async Task CrearMedico(Medicos medico)
        {
            using var connection = new SqlConnection(connectionString);
                        
            //var id = await connection.QuerySingleAsync<int>($"insert into medicos(Nombre,especializacion,experiencia,años_experiencia,foto) values ('{medico.Nombre}','{medico.Especializacion}','{medico.Experiencia}','{medico.Años_experiencia}','{medico.Foto}');SELECT SCOPE_IDENTITY()");

            var id = await connection.QuerySingleAsync<int>($@"insert into medicos(Nombre,especializacion,experiencia,años_experiencia,foto) values (@Nombre,@Especializacion,@Experiencia,@Años_experiencia,@Foto);SELECT SCOPE_IDENTITY();",medico);

        }
    }
}
