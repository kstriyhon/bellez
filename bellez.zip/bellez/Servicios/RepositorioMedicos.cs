﻿using bellez.Models;
using Dapper;
using Microsoft.Data.SqlClient;

namespace bellez.Servicios
{

    public interface IRepositorioMedicos
    {
        Task CrearMedico(Medicos medico);
        Task<IEnumerable<Clinicas>> getclinica(int id);
        Task<IEnumerable<Clinicas>> GetClinicas();
        Task<IEnumerable<Medicos>> getmedico(int id);
        Task<IEnumerable<Medicos>> getmedicos();
    }
    public class RepositorioMedicos : IRepositorioMedicos
    {

        private readonly string connectionString;
        public RepositorioMedicos(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("defaultConnections");
        }

        public async Task CrearMedico(Medicos medico)
        {

            using var connection = new SqlConnection(connectionString);

            //var id = await connection.QuerySingleAsync<int>($"insert into medicos(Nombre,especializacion,experiencia,años_experiencia,foto) values ('{medico.Nombre}','{medico.Especializacion}','{medico.Experiencia}','{medico.Años_experiencia}','{medico.Foto}');SELECT SCOPE_IDENTITY()");

            var id = await connection.QuerySingleAsync<int>($@"insert into medicos(Nombre,especializacion,experiencia,años_experiencia,foto) values (@Nombre,@Especializacion,@Experiencia,@Años_experiencia,@Foto);SELECT SCOPE_IDENTITY();", medico);



        }
        public async Task<IEnumerable<Medicos>> getmedico(int id)
        {
            using var connection = new SqlConnection(connectionString);
            return await connection.QueryAsync<Medicos>(@"SELECT id,nombre,especializacion,experiencia,años_experiencia,Foto " +
                                                       "from Medicos where id = @id", new { id });
        }

        public async Task<IEnumerable<Medicos>> getmedicos()
        {
            using var connection = new SqlConnection(connectionString);
            return await connection.QueryAsync<Medicos>(@"SELECT TOP 3 id,nombre,especializacion,experiencia,años_experiencia,Foto " +
                                                       "from Medicos");
        }

        public async Task<IEnumerable<Clinicas>> GetClinicas()
        {
            using var connection = new SqlConnection(connectionString);
            return await connection.QueryAsync<Clinicas>(@"SELECT TOP 3 * FROM clinicas");
        }

        public async Task<IEnumerable<Clinicas>> getclinica(int id)
        {
            using var connection = new SqlConnection(connectionString);
            return await connection.QueryAsync<Clinicas>(@"SELECT  * FROM clinicas where id = @id", new { id });
        }
    }



}

