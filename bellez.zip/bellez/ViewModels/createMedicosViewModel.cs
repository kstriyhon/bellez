﻿using System.ComponentModel.DataAnnotations;

namespace bellez.ViewModels
{
    public class createMedicosViewModel
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Especializacion { get; set; }
        public string Experiencia { get; set; }
        public int Años_experiencia { get; set; }
        public IFormFile Foto { get; set; }
    }
}
